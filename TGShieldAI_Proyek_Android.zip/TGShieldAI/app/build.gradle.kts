plugins { id("com.android.application") }
android { namespace = "com.tgshield.ai"; compileSdk = 35
 defaultConfig { applicationId = "com.tgshield.ai"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" } }
